# Dijkstra

### Steps to run
1. Open terminal and change directory to where the code is stored
2. In the terminal window, type
```
python3 Dijkstra-pathplanning-Gaurav-Raut.py
```
3. The code will ask for user's input of initial and goal coordinates.
4. Enter the coordinates and the algorithm will run and return optimal path if the node is found. Else, it will prompt the user that the node was not found.
